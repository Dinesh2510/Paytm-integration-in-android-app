-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 11, 2019 at 10:02 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simplified`
--
CREATE DATABASE IF NOT EXISTS `simplified` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `simplified`;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `shortdesc` varchar(500) NOT NULL,
  `rating` float NOT NULL,
  `price` double NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `shortdesc`, `rating`, `price`, `image`) VALUES
(1, 'Fluticasone (Flovent HFA)', 'Inhaled corticosteroids don\'t generally cause serious side effects. When side effects occur, they can include mouth and throat irritation and oral yeast infections. ', 4.7, 100, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(2, 'Montelukast', 'Inhaled corticosteroids don\'t generally cause serious side effects. When side effects occur, they can include mouth and throat irritation and oral yeast infections. ', 4.3, 60, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(3, 'Levosalbutamol', 'Levolin 1.25 mg Respules is a bronchodilator medicine that relaxes the muscles in the airways leading to the lung and improves the amount of air flow to and from the lungs. ', 4.2, 100, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(4, 'Ciprofloxacin', 'Ciprofloxacin is an antibiotic used to treat a number of bacterial infections. This includes bone and joint infections, intra abdominal infections,', 4, 300, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(6, 'Ciprofloxacin', 'Ciprofloxacin is an antibiotic used to treat a number of bacterial infections. This includes bone and joint infections, intra abdominal infections,', 4, 300, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(7, 'Ipratropium bromide ', ' Sold under the trade name Atrovent among others, is a medication which opens up the medium and large airways in the lungs. ', 4.6, 303, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(8, 'Levocetirizine', ' Levocetirizine is a third-generation, non-sedating antihistamine, developed from the second-generation antihistamine cetirizine.', 4.6, 303, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw'),
(9, 'Loratadine', ' Description:Loratadine, sold under the brand name Claritin among others, is a medication used to treat allergies. This includes allergic rhinitis and hives.', 4.6, 303, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS01HF_MH_9SVMZN-U6Qo5SA5vKV4g2kPsTs_MFt_MDEdHlswxw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
