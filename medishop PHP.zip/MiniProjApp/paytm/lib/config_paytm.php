<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
define('PAYTM_MERCHANT_KEY', 'UtA##Qb0s#DV&1L_'); 
?>
